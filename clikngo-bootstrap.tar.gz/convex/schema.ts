import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  tenants: defineTable({
    slug: v.string(),
    name: v.string(),
    address: v.optional(v.string()),
    phone: v.optional(v.string()),
    pickupConfig: v.optional(
      v.object({
        slotDurationMinutes: v.number(),
        maxOrdersPerSlot: v.number(),
        hours: v.array(
          v.object({
            day: v.number(),
            open: v.string(),
            close: v.string(),
          }),
        ),
      }),
    ),
    stripeCustomerId: v.optional(v.string()),
    subscriptionStatus: v.optional(
      v.union(
        v.literal("trial"),
        v.literal("active"),
        v.literal("past_due"),
        v.literal("canceled"),
      ),
    ),
  }).index("by_slug", ["slug"]),

  userProfiles: defineTable({
    userId: v.string(),
    tenantId: v.id("tenants"),
    role: v.union(
      v.literal("PATRON"),
      v.literal("VENDEUR"),
      v.literal("SUPERADMIN"),
    ),
  })
    .index("by_user", ["userId"])
    .index("by_tenant", ["tenantId"])
    .index("by_user_tenant", ["userId", "tenantId"]),

  products: defineTable({
    tenantId: v.id("tenants"),
    name: v.string(),
    description: v.optional(v.string()),
    brand: v.optional(v.string()),
    category: v.optional(v.string()),
    basePriceCents: v.number(),
    imageStorageIds: v.array(v.id("_storage")),
    active: v.boolean(),
  })
    .index("by_tenant_active", ["tenantId", "active"])
    .searchIndex("search_name", {
      searchField: "name",
      filterFields: ["tenantId", "active"],
    }),

  productVariants: defineTable({
    tenantId: v.id("tenants"),
    productId: v.id("products"),
    sku: v.string(),
    barcode: v.optional(v.string()),
    size: v.optional(v.string()),
    color: v.optional(v.string()),
    priceCents: v.optional(v.number()),
    stockOnHand: v.number(),
    reorderLevel: v.optional(v.number()),
  })
    .index("by_tenant_barcode", ["tenantId", "barcode"])
    .index("by_product", ["productId"])
    .index("by_tenant_lowstock", ["tenantId", "stockOnHand"]),

  stockMovements: defineTable({
    tenantId: v.id("tenants"),
    variantId: v.id("productVariants"),
    type: v.union(
      v.literal("SALE_INSTORE"),
      v.literal("SALE_ONLINE"),
      v.literal("RECEPTION"),
      v.literal("RETURN"),
      v.literal("ADJUSTMENT"),
      v.literal("LOSS"),
    ),
    quantity: v.number(),
    refOrderId: v.optional(v.id("orders")),
    notes: v.optional(v.string()),
    createdBy: v.string(),
    clientGeneratedId: v.optional(v.string()),
  })
    .index("by_tenant_time", ["tenantId"])
    .index("by_variant", ["variantId"])
    .index("by_client_id", ["clientGeneratedId"]),

  customers: defineTable({
    tenantId: v.id("tenants"),
    email: v.string(),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    phone: v.optional(v.string()),
  }).index("by_tenant_email", ["tenantId", "email"]),

  orders: defineTable({
    tenantId: v.id("tenants"),
    customerId: v.optional(v.id("customers")),
    status: v.union(
      v.literal("PENDING_PAYMENT"),
      v.literal("PAID_AWAITING_PICKUP"),
      v.literal("PICKED_UP"),
      v.literal("CANCELED"),
      v.literal("EXPIRED"),
    ),
    pickupSlotStart: v.number(),
    pickupSlotEnd: v.number(),
    totalAmountCents: v.number(),
    stripeCheckoutSessionId: v.optional(v.string()),
    stripePaymentIntentId: v.optional(v.string()),
    pickupCode: v.string(),
    pickedUpAt: v.optional(v.number()),
  })
    .index("by_tenant_status", ["tenantId", "status"])
    .index("by_pickup_code", ["pickupCode"])
    .index("by_stripe_session", ["stripeCheckoutSessionId"]),

  orderItems: defineTable({
    orderId: v.id("orders"),
    variantId: v.id("productVariants"),
    quantity: v.number(),
    priceAtPurchaseCents: v.number(),
  }).index("by_order", ["orderId"]),

  healthCounter: defineTable({
    value: v.number(),
  }),
});

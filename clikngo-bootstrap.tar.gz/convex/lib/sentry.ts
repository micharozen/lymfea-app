/**
 * Stub for Convex-side Sentry instrumentation.
 *
 * Convex actions run in a V8 isolate; @sentry/node has limited compatibility
 * there. For Step 1 we only expose a `captureException` helper that no-ops
 * when SENTRY_DSN is unset (local dev) and posts to the Sentry HTTP API in
 * production. Real instrumentation lands once an action with external side
 * effects is added (Stripe handlers in Week 6, OCR action in Week 4).
 */
export async function captureException(err: unknown, context?: Record<string, unknown>): Promise<void> {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) {
    console.error("[sentry stub]", err, context);
    return;
  }
  // TODO Week 4+: post to Sentry envelope endpoint or pull in @sentry/core
  // once we have an action wrapping pattern that needs it.
  console.error("[sentry]", err, context);
}

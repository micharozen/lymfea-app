import type { QueryCtx, MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { authComponent } from "../auth";

export type Role = "PATRON" | "VENDEUR" | "SUPERADMIN";

export type TenantCtx = {
  tenantId: Id<"tenants">;
  userId: string;
  role: Role;
};

/**
 * Fail-fast gate: every metier query/mutation must call this first.
 *
 * Resolves the active tenant from the Better Auth session (organizations
 * plugin) and verifies the caller has a userProfiles row binding them to that
 * tenant. Returns { tenantId, userId, role } or throws.
 */
export async function requireTenant(
  ctx: QueryCtx | MutationCtx,
): Promise<TenantCtx> {
  const user = await authComponent.safeGetAuthUser(ctx);
  if (!user) throw new Error("UNAUTHENTICATED");

  // The organizations plugin stores activeOrganizationId on the session.
  // We mirror Better Auth org membership via our own userProfiles table so we
  // can attach app-level roles and avoid round-tripping to the component.
  const userId = user._id as string;

  const profiles = await ctx.db
    .query("userProfiles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .collect();

  if (profiles.length === 0) {
    throw new Error("NO_TENANT_PROFILE");
  }

  // For step 1 we pick the first profile. Once multi-tenant per user lands
  // (V2: a patron with several boutiques), wire the active tenant from the
  // Better Auth session's activeOrganizationId.
  const profile = profiles[0];

  return {
    tenantId: profile.tenantId,
    userId,
    role: profile.role,
  };
}

export async function requireRole(
  ctx: QueryCtx | MutationCtx,
  allowed: Role[],
): Promise<TenantCtx> {
  const t = await requireTenant(ctx);
  if (!allowed.includes(t.role)) {
    throw new Error(`FORBIDDEN_ROLE: have=${t.role} need=${allowed.join("|")}`);
  }
  return t;
}

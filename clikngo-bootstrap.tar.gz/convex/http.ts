import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { authComponent, createAuth } from "./auth";
import { getStripe } from "./lib/stripe";
import { captureException } from "./lib/sentry";

const http = httpRouter();

// Better Auth routes (sign-in, sign-up, session, organizations) under /api/auth/*
authComponent.registerRoutes(http, createAuth, { cors: true });

// Stripe webhook stub. Verifies the signature, logs the event, returns 200.
// Real handlers (markOrderPaid, etc.) land Week 6.
http.route({
  path: "/stripe-webhook",
  method: "POST",
  handler: httpAction(async (_ctx, req) => {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret) {
      return new Response("STRIPE_WEBHOOK_SECRET not configured", { status: 500 });
    }
    const sig = req.headers.get("stripe-signature");
    if (!sig) return new Response("Missing stripe-signature", { status: 400 });

    const body = await req.text();
    try {
      const event = getStripe().webhooks.constructEvent(body, sig, secret);
      console.log(`[stripe-webhook] received ${event.type} (id=${event.id})`);
      return new Response(JSON.stringify({ received: true }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    } catch (err) {
      await captureException(err, { stripeSignature: sig });
      return new Response("Invalid signature", { status: 400 });
    }
  }),
});

export default http;

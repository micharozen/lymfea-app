import { query, mutation, internalMutation } from "./_generated/server";
import { requireTenant } from "./lib/tenant";

/**
 * Public health probe — confirms Convex is reachable. Returns "ok".
 */
export const ping = query({
  args: {},
  handler: async () => {
    return "ok" as const;
  },
});

/**
 * Reactive smoke test: increments a counter doc. Combined with `getCounter`
 * it proves a write in tab A propagates to a useQuery in tab B without
 * refresh.
 */
export const bumpCounter = mutation({
  args: {},
  handler: async (ctx) => {
    const existing = await ctx.db.query("healthCounter").first();
    if (existing) {
      await ctx.db.patch(existing._id, { value: existing.value + 1 });
      return existing.value + 1;
    }
    await ctx.db.insert("healthCounter", { value: 1 });
    return 1;
  },
});

export const getCounter = query({
  args: {},
  handler: async (ctx) => {
    const existing = await ctx.db.query("healthCounter").first();
    return existing?.value ?? 0;
  },
});

/**
 * Tenant-gated probe. Calls requireTenant and returns the resolved context.
 * Used to verify the multi-tenant gate works end-to-end.
 */
export const tenantPing = mutation({
  args: {},
  handler: async (ctx) => {
    const t = await requireTenant(ctx);
    return { tenantId: t.tenantId, role: t.role };
  },
});

/**
 * Internal helper used by the Better Auth `onCreate` trigger (wired in
 * Week 2 once we plug org creation -> tenant + userProfile creation).
 */
export const _seedTenantForUser = internalMutation({
  args: {},
  handler: async () => {
    return null;
  },
});

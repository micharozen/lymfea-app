import { cronJobs } from "convex/server";

const crons = cronJobs();

// Cron jobs land in Week 7:
//   - expirePending (every hour) -> sweep PENDING_PAYMENT > 30min
//   - expireUnpicked (daily) -> mark unpicked orders EXPIRED
//   - lowStockDigest (weekly) -> email patron
//   - driftCheck (hourly) -> reconcile stockOnHand vs sum(stockMovements)

export default crons;

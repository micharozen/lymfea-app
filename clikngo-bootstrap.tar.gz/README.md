# Clikngo

Stock vivant + click & collect SaaS for independent retailers.
Vertical de lancement : chausseurs indépendants en France.

## Stack

- Next.js 16 (App Router) + React 19 + Tailwind CSS 4 + TypeScript
- Convex (DB, queries/mutations/actions, httpAction, crons, file storage)
- Better Auth via `@convex-dev/better-auth` with the `organizations` plugin (multi-tenant)
- Stripe Checkout (clients) + Stripe Billing (SaaS) — Week 6+
- Resend (transactional emails) — Week 6+
- Anthropic Claude API (OCR fiches fournisseur) — Week 4
- Sentry (Next.js + Convex)
- Hosting: Vercel (frontend) + Convex Cloud (backend)
- Bun as package manager and runtime

## Step 1 layout

```
convex/
  auth.config.ts        # Convex auth provider (Better Auth JWT)
  auth.ts               # Better Auth server config (email+password, organizations plugin)
  convex.config.ts      # Registers the Better Auth Convex component
  crons.ts              # Empty (jobs land Week 7)
  health.ts             # ping / counter / tenantPing smoke tests
  http.ts               # Better Auth routes + Stripe webhook stub
  schema.ts             # Multi-tenant schema (tenants, products, stockMovements, orders, …)
  lib/
    tenant.ts           # requireTenant / requireRole — fail-fast multi-tenant gate
    stripe.ts           # Stripe singleton
    email.ts            # Resend singleton
    sentry.ts           # captureException stub
src/
  app/
    layout.tsx          # Convex + Better Auth providers
    page.tsx            # Marketing public + dev health beacon
    [tenantSlug]/       # Public C&C vitrine (per-tenant)
    (merchant)/
      app/              # PWA tablette
      admin/            # Back-office patron
    (super)/super/      # Super-admin console
    api/auth/[...all]/  # Better Auth Next.js handler (proxy to Convex .site)
  lib/auth-client.ts    # Better Auth React client
public/
  manifest.webmanifest
  icon-192.png / icon-512.png
  sw.js                 # No-op SW for Step 1; real offline queue lands Week 3
sentry.{client,server,edge}.config.ts
next.config.ts          # Sentry-conditional wrapping
```

## Manual setup (one-time, required before first run)

These steps need an interactive terminal — run them locally:

1. **Convex** — link a deployment (creates `_generated/` types):
   ```bash
   bunx convex dev
   ```
   This prompts to log in and create a new Convex project. It writes `NEXT_PUBLIC_CONVEX_URL` and `CONVEX_DEPLOYMENT` to `.env.local`. **Leave it running while developing.**

2. **`.env.local`** — copy and fill in:
   ```bash
   cp .env.local.example .env.local
   ```
   Set `NEXT_PUBLIC_CONVEX_SITE_URL` to the same Convex project but on the `.convex.site` host (e.g. `https://<deployment>.convex.site`). The publishable Stripe key, Sentry DSN, app domain, etc. go here.

3. **Convex env vars** — set the server-side secrets:
   ```bash
   bunx convex env set BETTER_AUTH_SECRET "$(openssl rand -base64 32)"
   bunx convex env set SITE_URL "http://localhost:3000"
   bunx convex env set STRIPE_SECRET_KEY "sk_test_…"
   bunx convex env set STRIPE_WEBHOOK_SECRET "whsec_…"
   bunx convex env set ANTHROPIC_API_KEY "sk-ant-…"
   bunx convex env set RESEND_API_KEY "re_…"
   bunx convex env set SENTRY_DSN "https://…"
   ```

4. **Stripe webhook** — point your Stripe dashboard at:
   ```
   https://<convex-deployment>.convex.site/stripe-webhook
   ```
   Use Stripe CLI for local testing:
   ```bash
   stripe listen --forward-to https://<convex-deployment>.convex.site/stripe-webhook
   ```

## Daily dev

In two terminals:
```bash
bun run dev          # Next.js on :3000
bun run convex:dev   # Convex — watches convex/ and pushes to dev deployment
```

## Scripts

- `bun run dev` — Next.js dev server
- `bun run build` — production build
- `bun run lint` — ESLint
- `bun run typecheck` — `tsc --noEmit`
- `bun run format` / `format:check` — Prettier
- `bun run convex:dev` — Convex dev server (codegen + push)
- `bun run convex:deploy` — Convex prod deploy

## Step 1 verification

Run after the manual setup:

1. `bun run dev` and `bun run convex:dev` start without errors.
2. `bun run typecheck` and `bun run lint` are clean.
3. Sign up via the Better Auth client → user appears in Convex dashboard (component table).
4. Create an organization → first call to a tenant-gated mutation succeeds; without org membership it throws `NO_TENANT_PROFILE`.
5. Open `/` in two tabs → "Bump counter" in tab A updates the counter in tab B in <1s.
6. `stripe trigger payment_intent.succeeded` (CLI pointed at the Convex .site URL) → the httpAction logs the event and returns 200.
7. Chrome DevTools → Application → Manifest reports no errors on `/app`.

## Out of scope for Step 1 (do NOT add yet)

- Scanner UI, offline queue, idempotent `recordSaleScan` → Week 3.
- OCR factures fournisseurs (Anthropic actions) → Week 4.
- Vitrine produit + tunnel C&C + Stripe Checkout handlers + emails → Weeks 5–6.
- Cron jobs (`expirePending`, `expireUnpicked`, `lowStockDigest`, `driftCheck`) → Week 7.
- Real Stripe webhook business logic → Week 6.
- E2E Playwright tests → Week 8.
- Subdomain-based tenant routing via middleware → revisit before pilot launch.
- Twenty CRM integration → V2.

## Open follow-ups for the operator

- Create the GitHub remote (`clikngo` repo) and push.
- Confirm domain ownership of `clikngo.io` + DNS for Vercel + Resend sending domain verification.
- Decide on the org-creation onboarding flow (whether the first-time patron creates an org via Better Auth org API and we mirror to a `tenants` row via an `onCreate` trigger — currently a TODO in `convex/auth.ts`).

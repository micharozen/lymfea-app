// No-op service worker for Step 1 — registers the PWA without offline behavior.
// Real offline queue (sales scans, idempotency replay) lands Week 3.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => {});

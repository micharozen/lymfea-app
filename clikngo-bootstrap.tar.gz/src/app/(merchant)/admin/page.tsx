export default function MerchantAdminPage() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-12 space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Back-office patron</h1>
      <p className="text-zinc-600">
        Catalogue, stock, commandes et IA fiches arrivent en weeks 2–7.
      </p>
    </main>
  );
}

export default function MerchantPwaPage() {
  return (
    <main className="mx-auto max-w-md px-6 py-12 space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Scanner</h1>
      <p className="text-zinc-600">
        PWA tablette merchant — placeholder. Caméra + scan EAN + queue offline arrivent en
        Week 3.
      </p>
    </main>
  );
}

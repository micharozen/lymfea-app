import type { Metadata } from "next";
import Script from "next/script";

export const metadata: Metadata = {
  title: "Clikngo — Tablette merchant",
  manifest: "/manifest.webmanifest",
};

export default function MerchantPwaLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Script id="sw-register" strategy="afterInteractive">
        {`if ("serviceWorker" in navigator) {
          window.addEventListener("load", () => {
            navigator.serviceWorker.register("/sw.js").catch(() => {});
          });
        }`}
      </Script>
      {children}
    </>
  );
}

import { convexBetterAuthNextJs } from "@convex-dev/better-auth/nextjs";

const { handler } = convexBetterAuthNextJs({
  convexUrl: process.env.NEXT_PUBLIC_CONVEX_URL as string,
  convexSiteUrl: process.env.NEXT_PUBLIC_CONVEX_SITE_URL as string,
});

export const { GET, POST } = handler;

export default function SuperAdminPage() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-12 space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Super-admin</h1>
      <p className="text-zinc-600">
        Onboarding tenants, vue Stripe Billing, support — arrive Week 7.
      </p>
    </main>
  );
}

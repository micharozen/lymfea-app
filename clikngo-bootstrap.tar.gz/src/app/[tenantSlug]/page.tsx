export default async function TenantVitrinePage({
  params,
}: {
  params: Promise<{ tenantSlug: string }>;
}) {
  const { tenantSlug } = await params;
  return (
    <main className="mx-auto max-w-3xl px-6 py-16 space-y-4">
      <h1 className="text-3xl font-semibold tracking-tight">Vitrine {tenantSlug}</h1>
      <p className="text-zinc-600">
        Public click &amp; collect store for tenant <code>{tenantSlug}</code>. Catalogue + tunnel
        C&amp;C land in weeks 5–6.
      </p>
    </main>
  );
}

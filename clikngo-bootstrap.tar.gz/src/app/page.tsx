"use client";

import Link from "next/link";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

export default function MarketingHomePage() {
  const ping = useQuery(api.health.ping);
  const counter = useQuery(api.health.getCounter);
  const bump = useMutation(api.health.bumpCounter);

  return (
    <main className="mx-auto max-w-3xl px-6 py-16 space-y-8">
      <header className="space-y-2">
        <h1 className="text-4xl font-semibold tracking-tight">Clikngo</h1>
        <p className="text-zinc-600">
          Stock vivant + click &amp; collect pour commerçants indépendants. Bientôt disponible.
        </p>
      </header>

      <section className="rounded-lg border border-zinc-200 p-6 space-y-3">
        <h2 className="text-sm uppercase tracking-wide text-zinc-500">Health beacon (dev only)</h2>
        <p className="text-sm">
          Convex ping: <code className="font-mono">{ping ?? "…"}</code>
        </p>
        <p className="text-sm">
          Reactive counter: <code className="font-mono">{counter ?? "…"}</code>
        </p>
        <button
          type="button"
          onClick={() => bump()}
          className="rounded bg-black px-4 py-2 text-sm text-white hover:bg-zinc-800"
        >
          Bump counter
        </button>
      </section>

      <nav className="text-sm text-zinc-500 space-x-4">
        <Link href="/app" className="underline">App tablette</Link>
        <Link href="/admin" className="underline">Back-office</Link>
        <Link href="/super" className="underline">Super-admin</Link>
      </nav>
    </main>
  );
}
